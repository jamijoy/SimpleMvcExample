﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SampleMvcTestJami.Controllers
{
    public class HomeController : Controller
    {
        //String unamee;
        [HttpGet]
        public ActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Registration(FormCollection fc)
        {
            //Session["Name"] = fc["name"].ToString();
            //return fc["name"].ToString()+" : "+fc["email"].ToString()+" : "+fc["uname"].ToString()+" : "+fc["pass1"].ToString()+" : "+fc["pass2"].ToString()+" : "+fc["gender"].ToString()+" : "+fc["day"].ToString()+" : "+fc["month"].ToString()+" : "+fc["year"].ToString();
            int n;
            //bool isNumeric = int.TryParse("123",out n);
            if (int.TryParse(fc["name"], out n).ToString() == "True" || fc["name"].ToString().Length==0)
            {
                ViewData["registermsg"] = "Please return a valid input as NAME";
                return View();
            }
            else if (fc["pass1"].ToString() != fc["pass2"].ToString())
            {
                ViewData["registermsg1"] = "Please enter your confirm password honestly";
                return View();
            }
            else if (fc["pass1"].ToString().Length<5)
            {
                ViewData["registermsg2"] = "Password must be of at least 5 Characters";
                return View();
            }
            else if (fc["uname"].ToString().Length<5)
            {
                ViewData["registermsg3"] = "UserName must be of at least 5 Characters";
                return View();
            }
            else if (Int32.Parse(fc["day"]) > 31 || Int32.Parse(fc["month"]) > 12 || Int32.Parse(fc["year"]) > 2012)
            {
                ViewData["registermsg4"] = "Please enter a Valid Date/year/month";
                return View();
            }            
            else
            {
                Session["Username"] = fc["uname"].ToString();
                Session["Password"]=fc["pass1"].ToString();
                return RedirectToAction("Login");
            }
        }
        //public String Login(String str)
        //{
        //    return str;
        //}
        public ActionResult Login(String unamee)
        {
            return View("Login");
        }
        public ActionResult Logincheck(FormCollection fc)
        {
            if (fc["uname"].ToString() == Session["Username"].ToString() && fc["pass"].ToString() == Session["Password"].ToString())
            {
                return View("Home");
            }
            else 
            {
                return View("Login");
            }
        }
    }
}
